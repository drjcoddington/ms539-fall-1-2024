﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
/* Name
 * Assignment
 * notes
 */
namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool done = false;
            char choice;
            int numTries;
            int count = 0;

            Console.WriteLine("Max # of games");
            numTries = Convert.ToInt32(Console.ReadLine()); 

            do
            {

                //  Console.Write("this is not going to a new line");
                Console.WriteLine("Welcome to Craps");
                Random rnd = new Random();
                Random rnd2 = new Random();
                int die1 = rnd.Next(1, 7);//1st is included , 2nd number is excluded
                Thread.Sleep(100);
                int die2 = rnd2.Next(1, 7);
                Console.WriteLine("die 1 = " + die1);
                Console.WriteLine("die 2 = " + die2);

                int sum = die1 + die2;
                if ((sum == 7) || (sum == 11))
                {
                    Console.WriteLine("CRAPS - you lose!");
                }
                else if ((die1 == die2) && (die1 % 2 == 0))
                {
                    Console.WriteLine("Wahoo - you won!");
                }
                else
                {
                    Console.WriteLine("PUSH");
                }
                count++; //count = count + 1;
                if (count >= numTries)
                {
                    done = true;
                }
                else
                {
                    Console.WriteLine("Do you want to play again? (Y/N)");
                    choice = Console.ReadKey().KeyChar;// only for reading a char
                    if ((choice == 'N') || (choice == 'n'))
                    {
                        done = true;
                    }
                }
            } while (!done);// do loop

            Console.WriteLine("thank you for playing");

          

        }
    }
}